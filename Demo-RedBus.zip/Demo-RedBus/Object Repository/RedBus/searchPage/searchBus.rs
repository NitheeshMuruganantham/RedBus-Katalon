<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>searchBus</name>
   <tag></tag>
   <elementGuidId>26efbd8b-4513-4875-8621-cd1c495a9108</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[text()='Search buses']</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
