<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>currrentMonCal</name>
   <tag></tag>
   <elementGuidId>e656acbf-c7ec-44d4-9018-118f25d9e44f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//p[@class='monthYear___d72513']</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
