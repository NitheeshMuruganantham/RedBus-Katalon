<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>fillPassengerDetails</name>
   <tag></tag>
   <elementGuidId>6f798a8b-ca1b-4140-82b9-22e1deccc140</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[text()='Fill passenger details']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
