<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>fromBusStop</name>
   <tag></tag>
   <elementGuidId>5dfceea1-803b-4f1b-9d97-e26e353481fd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[text()='Central Silk Board']/ancestor::div[@class='rightContent___adfb56']/following-sibling::div/div</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
