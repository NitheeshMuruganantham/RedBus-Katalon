import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable

import org.openqa.selenium.By
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.util.KeywordUtil
//import groovy.util.AntBuilder
import com.kms.katalon.core.annotation.Keyword
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.util.regex.Pattern
import java.util.stream.Collectors
import java.awt.Rectangle as Rectangle
import java.awt.Robot as Robot
import java.awt.Toolkit
import java.awt.datatransfer.Clipboard
import java.awt.datatransfer.StringSelection
import java.awt.image.BufferedImage as BufferedImage
import javax.imageio.ImageIO as ImageIO
import com.kms.katalon.core.webui.driver.DriverFactory
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.interactions.Actions
import org.openqa.selenium.Keys
import java.awt.Robot
import java.awt.event.KeyEvent


"Launching the browser"
WebUI.openBrowser("https://www.redbus.in/")

"Maximize the window"
WebUI.maximizeWindow()
 
WebUI.delay(3)
'Take Screenshot'
WebUI.takeScreenshot()

"From section"
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/searchPage/from'))

"From Dropdown selection"
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/searchPage/fromSug'))

"To section"
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/searchPage/to'))

"To Dropdown selection"
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/searchPage/toSug'))

"Calender select"
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/searchPage/dateOfJourney'))

 while(1<2){
		String currentMonth =WebUI.getText(findTestObject('Object Repository/RedBus/searchPage/currrentMonCal'))
		print(currentMonth)
		if( currentMonth.equalsIgnoreCase(Month))
		{
			WebUI.click(findTestObject('Object Repository/RedBus/searchPage/dateSelect',['text': travellingDate]))
			break
		}else
		{
			WebUI.click(findTestObject('Object Repository/RedBus/searchPage/calenderLeftNav'))
		}
		}


WebUI.delay(3)
'Take Screenshot'
WebUI.takeScreenshot()

"Click the search Bus"		
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/detailsSection/button', ['text': 'Search buses']))


"Flitering the bus type to AC"
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/searchPage/filterAC'))

"Sorting the price"
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/searchPage/priceSort'))
WebUI.delay(5)
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/searchPage/priceSort'))
WebUI.delay(5)

"Bus Selection"
WebDriver driver=DriverFactory.getWebDriver()
List<WebElement> listBus=driver.findElements(By.xpath("//div[contains(@class,'travelsName')]"))

for(WebElement bus: listBus)
{
	
	if(bus.getText().equalsIgnoreCase(BusName))
	{
	new Actions(driver).moveToElement(bus).perform();
	WebUI.delay(3)
	WebElement button = bus.findElement(By.xpath("./ancestor::div[contains(@class,'timeFareBoWrap')]/following-sibling::button"))
	println(bus.getText())
	button.click();
	}
	
	}
WebUI.delay(5)
'Take Screenshot'
WebUI.takeScreenshot()

"Seat Selection"
List<WebElement> listSeats=driver.findElements(By.xpath("//span[contains(@class,'sleeper__ind-seat')]/span[contains(@class,'sleeperPrice')]"))
	
for(WebElement seats: listSeats)
{
	if(seats.getText() != "Sold")
	{
	WebElement button = seats.findElement(By.xpath("./parent::span"))
	println(seats.getText())
	button.click();
	break
	}
}

WebUI.delay(3)
'Take Screenshot'
WebUI.takeScreenshot()

"clicking the button -Boarding point selection"
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/detailsSection/button', ['text': 'Select boarding & dropping points']))

"Bus stop-From"
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/detailsSection/fromBusStop'))

"Bus stop-To"
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/detailsSection/toBusStop'))

"Enter the mail id"
WebUI.setText(findTestObject('Object Repository/RedBus/detailsSection/inputField', ['text': 'Email ID']), mailId)

"Enter the Mob no"
WebUI.setText(findTestObject('Object Repository/RedBus/detailsSection/inputField', ['text': 'Phone']), MobNo)

"Select the state"
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/detailsSection/inputField', ['text': 'State of Residence']))
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/detailsSection/stateSelect', ['text': 'Tamil Nadu']))

WebUI.delay(3)
'Take Screenshot'
WebUI.takeScreenshot()

"Enter the Name"
WebUI.setText(findTestObject('Object Repository/RedBus/detailsSection/inputField', ['text': 'Name']), Name)

"Enter the Age"
WebUI.setText(findTestObject('Object Repository/RedBus/detailsSection/inputField', ['text': 'Age']), Age)

"Select the gender"
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/detailsSection/gender', ['text': 'Male']))

WebUI.delay(3)
'Take Screenshot'
WebUI.takeScreenshot()

"Select the Insurance"
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/detailsSection/insurance'))

'Take Screenshot'
WebUI.takeScreenshot()

"Click the button-Continue booking"
WebUI.enhancedClick(findTestObject('Object Repository/RedBus/detailsSection/button', ['text': 'Continue booking']))
WebUI.delay(5)


"closing the Browser"
WebUI.closeBrowser()