package org.example.listeners;

import io.qameta.allure.listener.TestLifecycleListener;
import io.qameta.allure.model.TestResult;

public class CustomizedTestLifecycleListener implements TestLifecycleListener {

    @Override
    public void beforeTestSchedule(TestResult result) {
        // do nothing
    }

    @Override
    public void afterTestSchedule(TestResult result) {
        // do nothing
    }

    @Override
    public void beforeTestUpdate(TestResult result) {
        // do nothing
    }

    @Override
    public void afterTestUpdate(TestResult result) {
        // do nothing
    }

    @Override
    public void beforeTestStart(TestResult result) {
        // result.setName("[TEST] " + result.getName());
    }

    @Override
    public void afterTestStart(TestResult result) {
        // do nothing
    }

    @Override
    public void beforeTestStop(TestResult result) {
        // Allure.addAttachment(result.getName() + "_screenshot", 
        //     new ByteArrayInputStream(BrowserFactory.takeScreenshot(result.getName())));
    }

    @Override
    public void afterTestStop(TestResult result) {
        // do nothing
    }

    @Override
    public void beforeTestWrite(TestResult result) {
        // do nothing
    }

    @Override
    public void afterTestWrite(TestResult result) {
        // do nothing
    }
}
