package org.example.listeners;

import io.qameta.allure.listener.StepLifecycleListener;
import io.qameta.allure.model.StepResult;

public class CustomizedStepLifecycleListener implements StepLifecycleListener {

    @Override
    public void beforeStepStart(StepResult result) {
        // result.setName("[STEP] " + result.getName());
    }

    @Override
    public void afterStepStart(StepResult result) {
        // do nothing
    }

    @Override
    public void beforeStepUpdate(StepResult result) {
        // do nothing
    }

    @Override
    public void afterStepUpdate(StepResult result) {
        // do nothing
    }

    @Override
    public void beforeStepStop(StepResult result) {
        // Allure.addAttachment(result.getName() + "_screenshot",
        //     new ByteArrayInputStream(BrowserFactory.takeScreenshot(result.getName())));
    }

    @Override
    public void afterStepStop(StepResult result) {
        // do nothing
    }
}
