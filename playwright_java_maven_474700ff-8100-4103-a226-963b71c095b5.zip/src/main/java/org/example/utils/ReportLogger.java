package org.example.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import io.qameta.allure.Allure;
import io.qameta.allure.Attachment;
import io.qameta.allure.Step;

public class ReportLogger {
    public static int failCounter = 0;
    public static int failStopCounter = 0;
    static Logger log = LogManager.getLogger(ReportLogger.class);

    @Step("{0}")
    public static void log(String message) {
        Allure.step(message);
        log.info(message);
    }

    public void info(String message) {
        Allure.step(Util.getCurrentTime("yyyy-MM-dd HH:mm:ss") + "\t INFO \t" + message);
        log.info(Util.getCurrentTime("yyyy-MM-dd HH:mm:ss") + "\t INFO \t" + message);
    }

    public void fail(String message) {
        Allure.step(Util.getCurrentTime("yyyy-MM-dd HH:mm:ss") + "\t FAILED \t" + message, io.qameta.allure.model.Status.FAILED);
        log.error(Util.getCurrentTime("yyyy-MM-dd HH:mm:ss") + "\t FAILED \t" + message);
        Util.takePageScreenshot();
        failCounter++;
    }

    public void failAndStop(String message) {
        Allure.step(Util.getCurrentTime("yyyy-MM-dd HH:mm:ss") + "\t FAILED \t" + message, io.qameta.allure.model.Status.FAILED);
        log.error(Util.getCurrentTime("yyyy-MM-dd HH:mm:ss") + "\t FAILED \t" + message);
        Util.takePageScreenshot();
        failStopCounter++;
        throw new AssertionError(Util.getCurrentTime("yyyy-MM-dd HH:mm:ss") + "\t FAILED \t" + message);
    }

    public void pass(String message) {
        Allure.step(Util.getCurrentTime("yyyy-MM-dd HH:mm:ss") + "\t PASSED \t" + message);
        log.info(Util.getCurrentTime("yyyy-MM-dd HH:mm:ss") + "\t PASSED \t" + message);
    }

    @Attachment(value = "{logMessage}", type = "text/plain")
    private static String attachLogToAllure(String logMessage) {
        return logMessage;
    }
}
