package org.example.utils;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

import com.microsoft.playwright.Page;
import io.qameta.allure.Allure;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.factory.BrowserFactory;

public class Util extends BrowserFactory{
    private static final Logger logger = LogManager.getLogger(Util.class);
    public static int count = 0;
    
    public static String getCurrentTime(String format) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        return LocalDateTime.now().format(formatter);
    }

    public static String screenshotPath(String ssNumber, String testCaseID) {
        String projectName = System.getProperty("PROJECT_NAME", "default_project");
        String reqID = System.getProperty("REQ_ID", "default_req");
        return projectName + "_" + reqID + "_" + testCaseID + "_" + ssNumber + ".png";
    }

    public static String screenshotNumberIncrementor() {
        DecimalFormat decimalFormat = new DecimalFormat("000");
        return decimalFormat.format(++count);
    }

    public static void takePageScreenshot() {
        try {
            String testCaseID=properties.getProperty("TESTCASE_ID");
            String ssNumber = screenshotNumberIncrementor();
            String path = screenshotPath(ssNumber, testCaseID);
            Path filePath = Paths.get(System.getProperty("user.dir"), "screenshots", path);
            
            byte[] screenshot = PlaywrightActions.actionsPage.screenshot(new Page.ScreenshotOptions().setPath(filePath).setFullPage(false));
            logger.info("Screenshot taken: " + filePath);
            Allure.addAttachment("Screenshot", new ByteArrayInputStream(screenshot));
        } catch (Exception e) {
            logger.error("Failed to take screenshot", e);
        }
    }

    public static void takeFullPageScreenshot() {
        try {
            
            String testCaseID=properties.getProperty("TESTCASE_ID");
            String ssNumber = screenshotNumberIncrementor();
            String path = screenshotPath(ssNumber, testCaseID);
            Path filePath = Paths.get(System.getProperty("user.dir"), "screenshots", path);
            
            byte[] screenshot = PlaywrightActions.actionsPage.screenshot(new Page.ScreenshotOptions().setPath(filePath).setFullPage(true));
            logger.info("Full-page Screenshot taken: " + filePath);
            Allure.addAttachment("Full Screenshot", new ByteArrayInputStream(screenshot));
        } catch (Exception e) {
            logger.error("Failed to take full-page screenshot", e);
        }
    }

    public static void logMethodName() {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        String methodName = stackTrace[2].getMethodName();
        System.setProperty("METHOD_NAME", methodName);
        logger.info("Current method: " + methodName);
    }

    public static double timeout() {
        return Double.parseDouble(System.getProperty("DEFAULT_TIMEOUT", "30.0"));
    }

    
    public static String getDecryptedPassword(String encryptedPassword) {
        return new String(Base64.getDecoder().decode(encryptedPassword),StandardCharsets.UTF_8);
    }
}
