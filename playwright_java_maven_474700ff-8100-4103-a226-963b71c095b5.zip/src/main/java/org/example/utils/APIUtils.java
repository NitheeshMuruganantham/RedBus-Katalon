package org.example.utils;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.RequestOptions;

import java.util.Map;

public class APIUtils {
    private APIRequestContext request;

    public APIUtils(String baseUrl) {
        Playwright playwright = Playwright.create();
        APIRequest requestContext = playwright.request();
        this.request = requestContext.newContext(new APIRequest.NewContextOptions().setBaseURL(baseUrl));
    }

    // Generic GET request
    public APIResponse sendGetRequest(String endpoint) {
        return request.get(endpoint);
    }

    // Generic POST request
    public APIResponse sendPostRequest(String endpoint, String body, Map<String, String> headers) {
        RequestOptions options = createRequestOptions(headers).setData(body);
        return request.post(endpoint, options);
    }

    // Generic PUT request
    public APIResponse sendPutRequest(String endpoint, String body, Map<String, String> headers) {
        RequestOptions options = createRequestOptions(headers).setData(body);
        return request.put(endpoint, options);
    }

    // Generic PATCH request
    public APIResponse sendPatchRequest(String endpoint, String body, Map<String, String> headers) {
        RequestOptions options = createRequestOptions(headers).setData(body);
        return request.patch(endpoint, options);
    }

    // Generic DELETE request
    public APIResponse sendDeleteRequest(String endpoint, Map<String, String> headers) {
        RequestOptions options = createRequestOptions(headers);
        return request.delete(endpoint, options);
    }

    // Helper method to create RequestOptions with headers
    private RequestOptions createRequestOptions(Map<String, String> headers) {
        RequestOptions options = RequestOptions.create();
        if (headers != null) {
            headers.forEach(options::setHeader); // Set headers one by one
        }
        return options;
    }

    public void close() {
        request.dispose();
    }
}