package org.example.utils;

import org.example.base.BaseTest;
import org.example.factory.BrowserFactory;
// import org.example.utils.ReportLogger;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.options.WaitForSelectorState;

public class PlaywrightActions extends BaseTest {  

    protected static Page actionsPage = BaseTest.page;
    private static final ReportLogger logger = new ReportLogger();
    // private static final ArrayList<Page> pagesList = new ArrayList<>();

    public String locatorName() {
        return BrowserFactory.properties.getProperty("METHOD_NAME");
    }

    public boolean isPresent(Locator locator) {
        boolean isVisible = false;
        try {
            // isVisible = ;
            if (locator.count() > 0) {
                isVisible = true;
            }
            logger.info("Checking if object '" + locatorName() + "' is present");
        } catch (PlaywrightException e) {
            logger.failAndStop(e.getMessage());
        }
        return isVisible;
    }

    public boolean click(Locator locator) {
        try {
            locator.click();
            logger.info("Object '" + locatorName() + "' is clicked on");
            return true;
        } catch (PlaywrightException e) {
            logger.failAndStop(e.getMessage());
            return false;
        }
    }

    public boolean fill(Locator locator, String value) {
        try {
            locator.fill(value);
            logger.info("Text '" + value + "' is set on object '" + locatorName() + "'");
            return true;
        } catch (PlaywrightException e) {
            logger.failAndStop(e.getMessage());
            return false;
        }
    }
    public String getTitle() {
        try {   
            String title = actionsPage.title();
            logger.info("Page title is: " + title);
            return title;
        } catch (PlaywrightException e) {
            logger.failAndStop(e.getMessage());
            return null;
        }
    }

    public boolean waitFor(Locator locator) {
        try {
            logger.info("Waiting for object '" + locatorName() + "'");
            locator.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE));
            return true;
        } catch (PlaywrightException e) {
            logger.failAndStop(e.getMessage());
            return false;
        }
    }
    public String getText(Locator locator) {
            logger.info("Text of object '" + locatorName() + "' is: '" + locator.textContent()+"'");
            return locator.textContent();
         
    }
    public boolean hover(Locator locator) {
        try {
            locator.hover();
            logger.info("Hover on object '" + locatorName() + "'");
            return true;
        } catch (PlaywrightException e) {
            logger.failAndStop(e.getMessage());
            return false;
        }
    }
    public boolean type(Locator locator, String value) {
        try {
            locator.pressSequentially(value);
            logger.info("Text '" + value + "' is set on object '" + locatorName() + "'");
            return true;
        } catch (PlaywrightException e) {
            logger.failAndStop(e.getMessage());
            return false;
        }
    }
    public boolean waitFor(Locator locator, int timeout) {
        try {
            logger.info("Waiting for object '" + locatorName() + "'");
            locator.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(timeout));
            return true;
        } catch (PlaywrightException e) {
            logger.failAndStop(e.getMessage());
            return false;
        }
    }
    public boolean waitFor(Locator locator, int timeout, String state) {
        try {
            logger.info("Waiting for object '" + locatorName() + "'");
            locator.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.valueOf(state)).setTimeout(timeout));
            return true;
        } catch (PlaywrightException e) {
            logger.failAndStop(e.getMessage());
            return false;
        }
    }
    public String getCurrentURL() {
        String currentUrl = actionsPage.url();
        logger.info("Current URL is: " + currentUrl);
        return actionsPage.url();
    }
    public void closeCurrentBrowser() {
        try {
            actionsPage.close();
            logger.info("Browser closed");
        } catch (PlaywrightException e) {
            logger.failAndStop(e.getMessage());
        }
    }
    public void verifyText(Locator locator, String expectedText) {
        try {
            String actualText = locator.textContent();
            if (actualText.equals(expectedText)) {
                logger.info("Text verification passed. Expected: " + expectedText + ", Actual: " + actualText);
            } else {
                logger.failAndStop("Text verification failed. Expected: " + expectedText + ", Actual: " + actualText);
            }
        } catch (PlaywrightException e) {
            logger.failAndStop(e.getMessage());
        }
    }
    public void delay(int seconds) {
        try {
            Thread.sleep(seconds * 1000);
            logger.info("Waited for " + seconds + " seconds");
        } catch (InterruptedException e) {
            logger.failAndStop(e.getMessage());
        }
    }
    public void doubleClick(Locator locator) {
        try {
            locator.dblclick();
            logger.info("Object '" + locatorName() + "' is double clicked on");
        } catch (PlaywrightException e) {
            logger.failAndStop(e.getMessage());
        }
    }
}
