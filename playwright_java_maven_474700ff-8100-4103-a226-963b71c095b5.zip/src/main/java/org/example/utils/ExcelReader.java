package org.example.utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

public class ExcelReader {
    private static final Logger logger = LoggerFactory.getLogger(ExcelReader.class);

/**
     * Reads a each cell data from an Excel sheet and return its value.
     */
    public static String getCellData(String filePath, String sheetName, int row, int column) {
        try (FileInputStream fis = new FileInputStream(new File(filePath))) {
            Workbook workbook = WorkbookFactory.create(fis);
            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                throw new IllegalArgumentException("Sheet with name '" + sheetName + "' not found.");
            }
            Row r = sheet.getRow(row);
            if (r == null) return "";
            Cell cell = r.getCell(column);
            if (cell == null) return "";
            return cell.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
    /**
     * Reads a single row from an Excel sheet and returns a key-value pair (Header -> RowData).
     */
    public static Map<String, String> readSingleRow(String filePath, String sheetName) {
        Map<String, String> data = new HashMap<>();

        try (FileInputStream file = new FileInputStream(new File(filePath));
             XSSFWorkbook workbook = new XSSFWorkbook(file)) {

            XSSFSheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                logger.error("Sheet '{}' not found in file '{}'", sheetName, filePath);
                return data;
            }

            Row headerRow = sheet.getRow(0); // Assuming first row is header
            Row dataRow = sheet.getRow(1); // Assuming second row contains values

            if (headerRow == null || dataRow == null) {
                logger.error("Invalid sheet format. Header or data row is missing.");
                return data;
            }

            for (int i = 0; i < headerRow.getLastCellNum(); i++) {
                String key = getCellValue(headerRow.getCell(i));
                String value = getCellValue(dataRow.getCell(i));
                data.put(key, value);
            }

        } catch (IOException e) {
            logger.error("Error reading Excel file: {}", e.getMessage());
        }
        return data;
    }

    /**
     * Reads multiple rows from an Excel sheet and returns a map of (Header -> List of values).
     */
    public static Map<String, List<String>> readMultipleRows(String filePath, String sheetName) {
        Map<String, List<String>> data = new HashMap<>();

        try (FileInputStream file = new FileInputStream(new File(filePath));
             XSSFWorkbook workbook = new XSSFWorkbook(file)) {

            XSSFSheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                logger.error("Sheet '{}' not found in file '{}'", sheetName, filePath);
                return data;
            }

            Row headerRow = sheet.getRow(0); // Assuming first row is header
            if (headerRow == null) {
                logger.error("Invalid sheet format. Header row is missing.");
                return data;
            }

            for (int i = 0; i < headerRow.getLastCellNum(); i++) {
                String key = getCellValue(headerRow.getCell(i));
                data.put(key, new ArrayList<>());
            }

            for (int rowNum = 1; rowNum <= sheet.getLastRowNum(); rowNum++) {
                Row row = sheet.getRow(rowNum);
                if (row != null) {
                    for (int colNum = 0; colNum < headerRow.getLastCellNum(); colNum++) {
                        String key = getCellValue(headerRow.getCell(colNum));
                        String value = getCellValue(row.getCell(colNum));
                        data.get(key).add(value);
                    }
                }
            }

        } catch (IOException e) {
            logger.error("Error reading Excel file: {}", e.getMessage());
        }
        return data;
    }

    /**
     * Helper method to extract cell values as Strings.
     */
    private static String getCellValue(Cell cell) {
        if (cell == null) return "";
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                return String.valueOf(cell.getNumericCellValue());
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            default:
                return "";
        }
    }
}
