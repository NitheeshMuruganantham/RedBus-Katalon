package org.example.pages.RedBus;

import com.microsoft.playwright.Locator;
import org.example.utils.PlaywrightActions;
import org.example.utils.Util;

public class detailsSection extends PlaywrightActions {
    private static final Locator insurance = actionsPage.locator("//div[@id='insuranceConfirmText']/div[contains(@class,'radioContainer')]");
    public static Locator insurance() {
        Util.logMethodName();
        return insurance;
    }

    private static final Locator fillPassengerDetails = actionsPage.locator("//button[text()='Fill passenger details']");
    public static Locator fillPassengerDetails() {
        Util.logMethodName();
        return fillPassengerDetails;
    }

    private static final Locator stateSelect = actionsPage.locator("//div[text()='${text}']");
    public static Locator stateSelect() {
        Util.logMethodName();
        return stateSelect;
    }

    private static final Locator fromBusStop = actionsPage.locator("//div[text()='Central Silk Board']/ancestor::div[@class='rightContent___adfb56']/following-sibling::div/div");
    public static Locator fromBusStop() {
        Util.logMethodName();
        return fromBusStop;
    }

    private static final Locator gender = actionsPage.locator("//label[text()='${text}']/following-sibling::span");
    public static Locator gender() {
        Util.logMethodName();
        return gender;
    }

    private static final Locator toBusStop = actionsPage.locator("//div[text()='Koyambedu']/ancestor::div[@class='rightContent___adfb56']/following-sibling::div/div");
    public static Locator toBusStop() {
        Util.logMethodName();
        return toBusStop;
    }

    private static final Locator button = actionsPage.locator("//button[text()='${text}']");
    public static Locator button() {
        Util.logMethodName();
        return button;
    }

    private static final Locator inputField = actionsPage.locator("//label[text()='${text}']/following-sibling::input");
    public static Locator inputField() {
        Util.logMethodName();
        return inputField;
    }

}