package org.example.pages.RedBus;

import com.microsoft.playwright.Locator;
import org.example.utils.PlaywrightActions;
import org.example.utils.Util;

public class searchPage extends PlaywrightActions {
    private static final Locator dateSelect = actionsPage.locator("//span[text()='${text}']");
    public static Locator dateSelect() {
        Util.logMethodName();
        return dateSelect;
    }

    private static final Locator dateOfJourney = actionsPage.locator("//span[text()='Date of Journey']");
    public static Locator dateOfJourney() {
        Util.logMethodName();
        return dateOfJourney;
    }

    private static final Locator calenderLeftNav = actionsPage.locator("//i[contains(@class,'icon icon-arrow arrow')][2]");
    public static Locator calenderLeftNav() {
        Util.logMethodName();
        return calenderLeftNav;
    }

    private static final Locator from = actionsPage.locator("//div[text()='From']");
    public static Locator from() {
        Util.logMethodName();
        return from;
    }

    private static final Locator searchBus = actionsPage.locator("//button[text()='Search buses']");
    public static Locator searchBus() {
        Util.logMethodName();
        return searchBus;
    }

    private static final Locator to = actionsPage.locator("//div[text()='To']");
    public static Locator to() {
        Util.logMethodName();
        return to;
    }

    private static final Locator filterAC = actionsPage.locator("//div[text()='AC']/parent::div[contains(@class,'container')]");
    public static Locator filterAC() {
        Util.logMethodName();
        return filterAC;
    }

    private static final Locator currrentMonCal = actionsPage.locator("//p[contains(@class,'monthYear___')]");
    public static Locator currrentMonCal() {
        Util.logMethodName();
        return currrentMonCal;
    }

    private static final Locator toSug = actionsPage.locator("//div[text()='Chennai']");
    public static Locator toSug() {
        Util.logMethodName();
        return toSug;
    }

    private static final Locator toInput = actionsPage.locator("//label[text()='To']/preceding-sibling::input");
    public static Locator toInput() {
        Util.logMethodName();
        return toInput;
    }

    private static final Locator priceSort = actionsPage.locator("//div[text()='Price']");
    public static Locator priceSort() {
        Util.logMethodName();
        return priceSort;
    }

    private static final Locator busList = actionsPage.locator("//ul[@class='srpList__ind-search-styles-module-scss-EOdde']/li");
    public static Locator busList() {
        Util.logMethodName();
        return busList;
    }

    private static final Locator onwardCal = actionsPage.locator("//div[@id='onwardCal']");
    public static Locator onwardCal() {
        Util.logMethodName();
        return onwardCal;
    }

    private static final Locator fromInput = actionsPage.locator("//label[text()='From']/parent::div");
    public static Locator fromInput() {
        Util.logMethodName();
        return fromInput;
    }

    private static final Locator fromSug = actionsPage.locator("//div[text()='Bangalore']");
    public static Locator fromSug() {
        Util.logMethodName();
        return fromSug;
    }

    private static final Locator selectBoarding = actionsPage.locator("//button[text()='Select boarding & dropping points']");
    public static Locator selectBoarding() {
        Util.logMethodName();
        return selectBoarding;
    }

}