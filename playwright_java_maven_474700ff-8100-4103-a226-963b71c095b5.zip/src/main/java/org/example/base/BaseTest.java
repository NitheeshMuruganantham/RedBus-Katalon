package org.example.base;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Tracing;
import org.example.factory.BrowserFactory;
import org.example.utils.ReportLogger;
import org.example.utils.Util;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Optional;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Properties;
import java.util.logging.Logger;

public class BaseTest {
    private static final BrowserFactory browserFactory = new BrowserFactory();
    protected static Properties properties = browserFactory.intializeConfigProperties();
    protected static Properties env_properties = browserFactory.intializeAllureEnvironmentProperties();
    protected static Properties default_properties = browserFactory.intializedefaultProperties();
    protected static Properties dev_properties = browserFactory.intializedevProperties();
    protected static Properties tst_properties = browserFactory.intializetstProperties();
    protected static final Logger logger = Logger.getLogger("BaseTest");
    protected static Page page;
    protected String browserName;

    @BeforeSuite
    public void beforeSuite() {
        // Delete all allure results
        File folder = new File("reports/allure-results");
        Arrays.stream(folder.listFiles()).filter(f->!f.getName().endsWith(".properties")).forEach(File::delete);
    }

    @BeforeMethod
    @Parameters({"browserName", "headless"})
    public void setUp(@Optional("chrome") String browserName, @Optional("false") String headless) throws IOException {
        this.browserName = browserName;

        // Initialize the browser
        page = BrowserFactory.initializeBrowser(browserName, headless);
        logger.info("Starting browser: " + browserName + " with headless set to " + headless);

        // Store host/user details
        env_properties.setProperty("Host_Name", System.getProperty("user.name")+" - "+InetAddress.getLocalHost().getHostName());
        env_properties.setProperty("Local_OS", System.getProperty("os.name"));
        env_properties.setProperty("Browser_version", BrowserFactory.getBrowser().browserType().name()+" - "+ browserName+ " "+ BrowserFactory.getBrowser().version());
        properties.store(new FileOutputStream("./reports/allure-results/environment.properties"), null);

         FileOutputStream file=new FileOutputStream(Paths.get("./reports/allure-results/environment.properties").toString());
        env_properties.store(file,null);
        file.close();

         // Launching URL
        String baseUrl = properties.getProperty("BASE_URL").trim();
        page.navigate(baseUrl);
        logger.info("Navigated to " + baseUrl + " successfully");

        // Start tracing
        BrowserFactory.getBrowserContext().tracing().start(new Tracing.StartOptions()
            .setScreenshots(true).setSnapshots(true)
            .setSources(true));
    }

    @AfterMethod
    public void tearDown(ITestContext context) throws IOException {
        if(ReportLogger.failCounter>0 && ReportLogger.failStopCounter==0){
            ReportLogger logger=new ReportLogger();
            logger.failAndStop("Test has failed steps");
        }
        Util.count=1;
        logger.info("SCreenshot index reset complete");
        // Stop tracing
        BrowserFactory.getBrowserContext().tracing().stop(new Tracing.StopOptions()
            .setPath(new File("./traces/" + context.getCurrentXmlTest().getSuite().getName() + ".zip").toPath()));

        logger.info("Closing the browser");
        page.close();
    }
}
