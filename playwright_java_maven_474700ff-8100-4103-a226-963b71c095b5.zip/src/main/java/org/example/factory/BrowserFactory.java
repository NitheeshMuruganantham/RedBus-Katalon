package org.example.factory;

import com.microsoft.playwright.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.Properties;

public class BrowserFactory {
    public static Properties properties;
    public static Properties env_properties;
    public static Properties default_properties;
    public static Properties dev_properties;
    public static Properties tst_properties;
    private static final ThreadLocal<Playwright> tlPlaywright = new ThreadLocal<>();
    private static final ThreadLocal<Browser> tlBrowser = new ThreadLocal<>();
    private static final ThreadLocal<BrowserContext> tlContext = new ThreadLocal<>();
    private static final ThreadLocal<Page> tlPage = new ThreadLocal<>();

    public static Playwright getPlaywright() {
        return tlPlaywright.get();
    }

    public static Browser getBrowser() {
        return tlBrowser.get();
    }

    public static BrowserContext getBrowserContext() {
        return tlContext.get();
    }

    public static Page getPage() {
        return tlPage.get();
    }

    public static Page initializeBrowser(String browserName, String headless) throws IllegalArgumentException {
        boolean isHeadless = Boolean.parseBoolean(headless);

        tlPlaywright.set(Playwright.create());

        switch (browserName.toLowerCase()) {
            case "chrome":
                tlBrowser.set(getPlaywright().chromium().launch(new BrowserType.LaunchOptions().setChannel("chrome").setHeadless(isHeadless)));
                break;
            case "edge":
                tlBrowser.set(getPlaywright().chromium().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(isHeadless)));
                break;
            case "firefox":
                tlBrowser.set(getPlaywright().firefox().launch(new BrowserType.LaunchOptions().setHeadless(isHeadless)));
                break;
            case "webkit":
                tlBrowser.set(getPlaywright().webkit().launch(new BrowserType.LaunchOptions().setHeadless(isHeadless)));
                break;
            default:
                throw new IllegalArgumentException("Invalid browser. Use: chrome, edge, firefox, or webkit.");
        }

        tlContext.set(getBrowser().newContext(new Browser.NewContextOptions().setIgnoreHTTPSErrors(true)));
        tlPage.set(getBrowserContext().newPage());

        return getPage();
    }

    public Properties intializeConfigProperties() {
        try {
            ClassLoader classLoader = getClass().getClassLoader();
        String configUrl=classLoader.getResource("config/config.properties").getPath();
        configUrl=URLDecoder.decode(configUrl, "UTF-8");
        FileInputStream configStream = new FileInputStream(configUrl);
        properties = new Properties();
            properties.load(configStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return properties;
    }

    //initialize default properties
    public Properties intializedefaultProperties() {
        try {
            FileInputStream defaultStream = new FileInputStream("./src/test/resources/config/default.properties");
            default_properties = new Properties();
            default_properties.load(defaultStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return default_properties;
    }

    //initialize dev properties
    public Properties intializedevProperties() {
        try {
            FileInputStream devStream = new FileInputStream("./src/test/resources/config/dev.properties");
            dev_properties = new Properties();
            dev_properties.load(devStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return dev_properties;
    }

    //initialize tst properties
    public Properties intializetstProperties() {
        try {
            FileInputStream tstStream = new FileInputStream("./src/test/resources/config/tst.properties");
            tst_properties = new Properties();
            tst_properties.load(tstStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tst_properties;
    }

    public Properties intializeAllureEnvironmentProperties() {
        try{ FileInputStream envStream = new FileInputStream("./reports/allure-results/environment.properties");
            env_properties =new Properties();
            env_properties.load(envStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return env_properties;
    }
}
