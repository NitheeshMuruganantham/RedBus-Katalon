package org.example.tests.Demo;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;
import com.microsoft.playwright.options.WaitForSelectorState;
import io.qameta.allure.Description;
import io.qameta.allure.testng.Tag;
import org.example.base.BaseTest;
import org.example.pages.RedBus.detailsSection;
import org.example.pages.RedBus.searchPage;
import org.example.utils.PlaywrightActions;
import org.example.utils.Util;
import org.testng.annotations.Test;

public class TC01_Redbus_BusBooking extends BaseTest {

  @Test(testName = "TC01_Redbus_BusBooking")
  @Description("Bus booking through Red bus Web site")
  @Tag("Test Case")
  public void testBusBooking() {
    PlaywrightActions actions = new PlaywrightActions();
    try {
      // Opening browser and navigating to Redbus
      logger.info("Launching the browser on Redbus.in");
      actionsPage.navigate("https://www.redbus.in/");
      Util.logMethodName();
      
      // Maximizing the window
      actionsPage.evaluate("() => window.resizeTo(screen.availWidth, screen.availHeight)");
      logger.info("Window maximized");
      
      actions.delay(3);
      
      // From section
      actions.click(searchPage.from());
      actions.click(searchPage.fromSug());
      
      // To section
      actions.click(searchPage.to());
      actions.click(searchPage.toSug());
      
      // Calender select
      actions.click(searchPage.dateOfJourney());
      while (true) {
        String currentMonth = searchPage.currrentMonCal().textContent();
        logger.info("Current month in calendar: " + currentMonth);
        if (currentMonth.equalsIgnoreCase(properties.getProperty("Month"))) {
          actions.click(searchPage.dateSelect().locator("[text='" + properties.getProperty("travellingDate") + "']"));
          break;
        } else {
          actions.click(searchPage.calenderLeftNav());
        }
      }
      
      actions.delay(3);
      
      // Search buses
      actions.click(searchPage.searchBus());
      
      // Filter and sort
      actions.click(searchPage.filterAC());
      actions.click(searchPage.priceSort());
      actions.delay(5);
      actions.click(searchPage.priceSort());
      actions.delay(5);
      
      // Bus Selection
      Locator listBus = actionsPage.locator("//div[contains(@class,'travelsName')]");
      for (Locator bus : listBus.locatorList()) {
        if (bus.textContent().equalsIgnoreCase(properties.getProperty("BusName"))) {
          bus.scrollIntoViewIfNeeded();
          actions.delay(3);
          bus.locator("./ancestor::div[contains(@class,'timeFareBoWrap')]/following-sibling::button").click();
          break;
        }
      }
      
      actions.delay(5);
      
      // Seat Selection
      Locator listSeats = actionsPage.locator("//span[contains(@class,'sleeper__ind-seat')]/span[contains(@class,'sleeperPrice')]");
      for (Locator seats : listSeats.locatorList()) {
        if (!seats.textContent().equalsIgnoreCase("Sold")) {
          seats.locator("./parent::span").click();
          break;
        }
      }
      
      actions.delay(3);
      
      // Boarding and Dropping point
      actions.click(detailsSection.selectBoarding());
      actions.click(detailsSection.fromBusStop());
      actions.click(detailsSection.toBusStop());
      
      // Entering details
      actions.fill(detailsSection.inputField().locator("[text='Email ID']"), properties.getProperty("mailId"));
      actions.fill(detailsSection.inputField().locator("[text='Phone']"), properties.getProperty("MobNo"));
      actions.click(detailsSection.inputField().locator("[text='State of Residence']"));
      actions.click(detailsSection.stateSelect().locator("[text='Tamil Nadu']"));
      actions.delay(3);
      
      // Entering passenger info
      actions.fill(detailsSection.inputField().locator("[text='Name']"), properties.getProperty("Name"));
      actions.fill(detailsSection.inputField().locator("[text='Age']"), properties.getProperty("Age"));
      actions.click(detailsSection.gender().locator("[text='Male']"));
      actions.delay(3);
      
      // Insurance selection
      actions.click(detailsSection.insurance());
      
      // Continue booking
      actions.click(detailsSection.button().locator("[text='Continue booking']"));
      actions.delay(5);
      
    } catch (Exception e) {
      logger.failAndStop(e.getMessage());
    } finally {
      logger.info("Closing the browser");
      actionsPage.close();
    }
  }
}